import hashlib

def sha1_hash(text):
    # Create a new sha1 hash object
    sha1 = hashlib.sha1()
    
    # Update the hash object with the bytes of the text
    sha1.update(text.encode('utf-8'))
    
    # Get the hex representation of the digest
    return sha1.hexdigest()

def main():
    print("--- SHA-1 Algorithm ---")
    
    print("\n[Test 1] Standard hashing of a regular string")
    text1 = input("Enter a string to hash: ")
    hash1 = sha1_hash(text1)
    print(f"Original Text: '{text1}'")
    print(f"SHA-1 Hash: {hash1}")
    print(f"Length of hash: {len(hash1) * 4} bits ({len(hash1)} hex characters)")
    
    print("\n[Test 2] Demonstrating Avalanche Effect (Small change = Large hash difference)")
    text2 = input("Enter another string with a very minor change: ")
    hash2 = sha1_hash(text2)
    print(f"Modified Text: '{text2}'")
    print(f"SHA-1 Hash: {hash2}")
    
    # Count bit differences to show avalanche effect (approximate hex character differences)
    differences = sum(1 for a, b in zip(hash1, hash2) if a != b)
    print(f"\n=> Avalanche Effect: Changing small parts of input resulted in {differences} out of {len(hash1)} hex characters changing.")

if __name__ == "__main__":
    main()
