# SHA-1 Implementation and Avalanche Effect

### Overview
SHA-1 (Secure Hash Algorithm 1) is a cryptographic hash function which takes an input and produces a 160-bit (20-byte) hash value known as a message digest. This digest is typically rendered as a hexadecimal number, 40 digits long.

### Properties of SHA-1
1. **Deterministic:** The same message always results in the exact same hash.
2. **Quick Computation:** Generating the hash of any given message is mathematically fast.
3. **Pre-image Resistance:** It is infeasible to generate the message from its hash value except by trying all possible messages.
4. **Small Changes Effect (Avalanche Effect):** A small change to a message should change the hash value so extensively that the new hash value appears uncorrelated with the old hash value.
5. **Collision Resistance:** It must be highly improbable to find two different messages that yield the same hash value.

### Avalanche Effect
In cryptography, the avalanche effect is the desirable property of cryptographic algorithms where a very small change in the input (such as flipping a single bit) causes a drastic and completely unpredictable change in the output (e.g., half the output bits flip). 

In our SHA-1 script, this is demonstrated manually: when changing one letter of the input string string, almost the entirety of the 40-character hex output dynamically updates as expected by the SHA-1 specifications.
