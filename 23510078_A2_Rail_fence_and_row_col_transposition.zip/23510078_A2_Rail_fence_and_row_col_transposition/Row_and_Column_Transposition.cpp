#include <bits/stdc++.h>
using namespace std;

string encryptRowColumn(string text, string key) {
    int cols = key.length();
    int rows = (text.length() + cols - 1) / cols;

    vector<vector<char>> matrix(rows, vector<char>(cols, 'X'));

    int k = 0;
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            if (k < text.length())
                matrix[i][j] = text[k++];

    vector<pair<char, int>> order;
    for (int i = 0; i < cols; i++)
        order.push_back({key[i], i});

    sort(order.begin(), order.end());

    string cipher = "";
    for (auto p : order) {
        int col = p.second;
        for (int i = 0; i < rows; i++)
            cipher += matrix[i][col];
    }

    return cipher;
}

string decryptRowColumn(string cipher, string key) {
    int cols = key.length();
    int rows = cipher.length() / cols;

    vector<pair<char, int>> order;
    for (int i = 0; i < cols; i++)
        order.push_back({key[i], i});

    sort(order.begin(), order.end());

    vector<vector<char>> matrix(rows, vector<char>(cols));
    int k = 0;

    for (auto p : order) {
        int col = p.second;
        for (int i = 0; i < rows; i++)
            matrix[i][col] = cipher[k++];
    }

    string text = "";
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            text += matrix[i][j];

    return text;
}

int main() {
    string text = "killkoronavirusattwelveamtomorrow";
    string key = "4312567";

    string enc = encryptRowColumn(text, key);
    cout << "Encrypted: " << enc << endl;
    cout << "Decrypted: " << decryptRowColumn(enc, key) << endl;

    return 0;
}

