#include <bits/stdc++.h>
using namespace std;

string encryptRailFence(string text, int key) {
    if (key == 1) return text;

    vector<string> rail(key);
    int dir = 1, row = 0;

    for (char c : text) {
        rail[row] += c;
        row += dir;

        if (row == 0 || row == key - 1)
            dir = -dir;
    }

    string cipher = "";
    for (string r : rail)
        cipher += r;

    return cipher;
}


string decryptRailFence(string cipher, int key) {
    if (key == 1) return cipher;

    int len = cipher.length();
    vector<vector<char>> rail(key, vector<char>(len, '\n'));

    int dir = 1, row = 0;
    for (int i = 0; i < len; i++) {
        rail[row][i] = '*';
        row += dir;

        if (row == 0 || row == key - 1)
            dir = -dir;
    }

    int index = 0;
    for (int i = 0; i < key; i++)
        for (int j = 0; j < len; j++)
            if (rail[i][j] == '*' && index < len)
                rail[i][j] = cipher[index++];

    string result = "";
    row = 0; dir = 1;
    for (int i = 0; i < len; i++) {
        result += rail[row][i];
        row += dir;

        if (row == 0 || row == key - 1)
            dir = -dir;
    }

    return result;
}

int main() {
    string str;
    cin>>str;

    int key;
    cin>>key;

    string text=str;

    string enc = encryptRailFence(text, key);
    cout << "Encrypted: " << enc << endl;
    cout << "Decrypted: " << decryptRailFence(enc, key) << endl;

    return 0;
}
