#include <bits/stdc++.h>
using namespace std;

string generateKey(string text, string key){
    int x = text.size();

    for(int i=0; ; i++){
        if(x == i) i = 0;
        if(key.size() == text.size()) break;
        key += key[i];
    }
    return key;
}

string encryptVigenere(string text, string key){
    string cipher = "";

    for(int i=0;i<text.size();i++){
        char c = ((text[i] + key[i]) % 26) + 'A';
        cipher += c;
    }
    return cipher;
}

string decryptVigenere(string cipher, string key){
    string text = "";

    for(int i=0;i<cipher.size();i++){
        char c = ((cipher[i] - key[i] + 26) % 26) + 'A';
        text += c;
    }
    return text;
}

int main(){
    
    string text,key;
    cout<<"Provide a Secrete key: "; //HELLOWORLD
    cin>>key;
    cout<<"Provide a text: ";       // KEY
    cin>>text;

    key = generateKey(text,key);
    string enc = encryptVigenere(text,key);
    string dec = decryptVigenere(enc,key);

    cout<<"Encrypted: "<<enc<<endl;
    cout<<"Decrypted: "<<dec<<endl;
}
