#include <bits/stdc++.h>
using namespace std;

char matrix[5][5];

void generateMatrix(string key)
{
    bool used[26] = {false};

    key.erase(remove(key.begin(), key.end(), ' '), key.end());

    int row = 0, col = 0;

    for (char c : key)
    {
        if (c == 'J')
            c = 'I';

        if (!used[c - 'A'])
        {
            matrix[row][col++] = c;
            used[c - 'A'] = true;

            if (col == 5)
            {
                row++;
                col = 0;
            }
        }
    }

    for (char c = 'A'; c <= 'Z'; c++)
    {
        if (c == 'J')
            continue;

        if (!used[c - 'A'])
        {
            matrix[row][col++] = c;

            if (col == 5)
            {
                row++;
                col = 0;
            }
        }
    }
}

pair<int, int> findPos(char c)
{
    if (c == 'J')
        c = 'I';

    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
            if (matrix[i][j] == c)
                return {i, j};

    return {-1, -1};
}

string prepareText(string text)
{
    string res = "";

    for (int i = 0; i < text.size(); i++)
    {
        if (text[i] == 'J')
            text[i] = 'I';

        res += text[i];

        if (i + 1 < text.size() && text[i] == text[i + 1])
            res += 'X';
    }

    if (res.size() % 2)
        res += 'X';

    return res;
}

string encryptPlayfair(string text)
{
    string cipher = "";

    for (int i = 0; i < text.size(); i += 2)
    {
        auto p1 = findPos(text[i]);
        auto p2 = findPos(text[i + 1]);

        if (p1.first == p2.first)
        {
            cipher += matrix[p1.first][(p1.second + 1) % 5];
            cipher += matrix[p2.first][(p2.second + 1) % 5];
        }
        else if (p1.second == p2.second)
        {
            cipher += matrix[(p1.first + 1) % 5][p1.second];
            cipher += matrix[(p2.first + 1) % 5][p2.second];
        }
        else
        {
            cipher += matrix[p1.first][p2.second];
            cipher += matrix[p2.first][p1.second];
        }
    }

    return cipher;
}

string decryptPlayfair(string text)
{
    string plain = "";

    for (int i = 0; i < text.size(); i += 2)
    {
        auto p1 = findPos(text[i]);
        auto p2 = findPos(text[i + 1]);

        if (p1.first == p2.first)
        {
            plain += matrix[p1.first][(p1.second + 4) % 5];
            plain += matrix[p2.first][(p2.second + 4) % 5];
        }
        else if (p1.second == p2.second)
        {
            plain += matrix[(p1.first + 4) % 5][p1.second];
            plain += matrix[(p2.first + 4) % 5][p2.second];
        }
        else
        {
            plain += matrix[p1.first][p2.second];
            plain += matrix[p2.first][p1.second];
        }
    }

    return plain;
}

int main()
{
    string key,text;   
    cout<<" Provide a secrete key: ";
    cin>>key;
    cout<<" Provide a Text: ";   // monarchy
    cin>>text;

    generateMatrix(key);

    text = prepareText(text);

    string enc = encryptPlayfair(text);
    string dec = decryptPlayfair(enc);

    cout << "Encrypted: " << enc << endl;
    cout << "Decrypted: " << dec << endl;
}
