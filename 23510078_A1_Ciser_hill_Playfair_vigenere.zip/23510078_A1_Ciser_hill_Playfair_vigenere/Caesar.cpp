#include <bits/stdc++.h>
using namespace std;

string encryptCaesar(string text, int key) {
    string result = "";

    for(char c : text){
        if(isalpha(c)){
            char base = isupper(c) ? 'A' : 'a';
            result += (c - base + key) % 26 + base;
        }
        else result += c;
    }
    return result;
}

string decryptCaesar(string text, int key) {
    return encryptCaesar(text, 26 - key);
}

int main(){
    string text;  // wce
    cin>>text;    //ex=3
    int key;
    cin>>key;

    string enc = encryptCaesar(text, key);
    string dec = decryptCaesar(enc, key);

    cout<<"Encrypted: "<<enc<<endl;
    cout<<"Decrypted: "<<dec<<endl;
}
