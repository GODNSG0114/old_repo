#include <bits/stdc++.h>
using namespace std;

int modInverse(int a){
    a = a % 26;
    for(int x=1;x<26;x++)
        if((a*x)%26==1)
            return x;
    return -1;
}

void encryptHill(string text, int key[2][2]){
    for(int i=0;i<text.size();i+=2){
        int a = text[i]-'A';
        int b = text[i+1]-'A';

        char c1 = (key[0][0]*a + key[0][1]*b)%26 + 'A';
        char c2 = (key[1][0]*a + key[1][1]*b)%26 + 'A';

        cout<<c1<<c2;
    }
}

void decryptHill(string text, int key[2][2]){
    int det = key[0][0]*key[1][1] - key[0][1]*key[1][0];
    det = (det%26+26)%26;

    int invDet = modInverse(det);

    int invKey[2][2];

    invKey[0][0] = key[1][1]*invDet %26;
    invKey[1][1] = key[0][0]*invDet %26;
    invKey[0][1] = (-key[0][1]+26)*invDet %26;
    invKey[1][0] = (-key[1][0]+26)*invDet %26;

    for(int i=0;i<text.size();i+=2){
        int a = text[i]-'A';
        int b = text[i+1]-'A';

        char c1 = (invKey[0][0]*a + invKey[0][1]*b)%26 + 'A';
        char c2 = (invKey[1][0]*a + invKey[1][1]*b)%26 + 'A';

        cout<<c1<<c2;
    }
}

int main(){
    string text;
    cin>>text;      // help

    int key[2][2]={{3,3},{2,5}};

    cout<<"Encrypted: ";
    encryptHill(text,key);

    cout<<"\nDecrypted: ";
    decryptHill("HIAT",key);
}
