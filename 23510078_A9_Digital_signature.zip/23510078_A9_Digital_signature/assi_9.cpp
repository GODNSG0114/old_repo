#include <iostream>
#include <cmath>
using namespace std;

long long modExp(long long base, long long exp, long long mod) {
    long long result = 1;
    base = base % mod;
    while (exp > 0) {
        if (exp % 2 == 1)
            result = (result * base) % mod;
        exp = exp >> 1;
        base = (base * base) % mod;
    }
    return result;
}

long long modInverse(long long k, long long q) {
    for (long long i = 1; i < q; i++) {
        if ((k * i) % q == 1)
            return i;
    }
    return -1;
}

long long hashFunction(long long message) {
    return message % 100;
}

int main() {
    long long p = 23, q = 11, g = 2;   // public parameter , g = alfa , q = prime diviser of(p-1)
    long long x = 3;                   // private key
    long long y = modExp(g, x, p);     // public key

    long long message;
    cout << "Enter message: ";
    cin >> message;

    long long h = hashFunction(message);

    long long k = 7;
    long long r = modExp(g, k, p) % q;    // g^x mod p
    long long k_inv = modInverse(k, q);   // k^(-1) mod q

    long long s = (k_inv * (h + x * r)) % q;

    cout << "\nSignature:\n";
    cout << "r = " << r << "\ns = " << s << endl;



    //  verification fase 
    long long w = modInverse(s, q);
    long long u1 = (h * w) % q;
    long long u2 = (r * w) % q;

    long long v = ((modExp(g, u1, p) * modExp(y, u2, p)) % p) % q;   // (g^u1 . y^u2 mod p) mod q;

    if (v == r)
        cout << "\nSignature Verified Successfully\n";
    else
        cout << "\nVerification Failed\n";

    return 0;
}
