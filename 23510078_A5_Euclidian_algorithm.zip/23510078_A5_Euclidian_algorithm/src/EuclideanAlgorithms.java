import java.util.Scanner;

public class EuclideanAlgorithms {

    // Function to compute GCD using Euclidean Algorithm
    public static int gcd(int a, int b) {
        while (b != 0) {
            int r = a % b;  // remainder
            a = b;
            b = r;
        }
        return a;
    }

    // Function to compute Extended Euclidean Algorithm
    // Returns gcd and finds x and y such that ax + by = gcd(a, b)
    public static int extendedGCD(int a, int b, int[] xy) {
        if (b == 0) {
            xy[0] = 1;  // x = 1
            xy[1] = 0;  // y = 0
            return a;
        }

        int[] temp = new int[2];
        int gcd = extendedGCD(b, a % b, temp);

        xy[0] = temp[1];
        xy[1] = temp[0] - (a / b) * temp[1];

        return gcd;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first positive integer: ");
        int a = sc.nextInt();

        System.out.print("Enter second positive integer: ");
        int b = sc.nextInt();

        // Euclidean Algorithm
        int gcdValue = gcd(a, b);
        System.out.println("\nGCD using Euclidean Algorithm = " + gcdValue);

        // Extended Euclidean Algorithm
        int[] xy = new int[2];
        int gcdExt = extendedGCD(a, b, xy);

        System.out.println("\nExtended Euclidean Algorithm:");
        System.out.println("GCD = " + gcdExt);
        System.out.println("x = " + xy[0] + ", y = " + xy[1]);
        System.out.println("Verification: " + a + "(" + xy[0] + ") + "
                + b + "(" + xy[1] + ") = " + gcdExt);

        sc.close();
    }
}