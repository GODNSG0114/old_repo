import java.util.Scanner;

public class DiffieHellman {

    // Function for modular exponentiation (g^x mod p)
    public static long modExp(long base, long exp, long mod) {
        long result = 1;
        base = base % mod;

        while (exp > 0) {
            // If exponent is odd
            if (exp % 2 == 1)
                result = (result * base) % mod;

            exp = exp / 2;
            base = (base * base) % mod;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Public values
        System.out.print("Enter prime number (q): ");
        long p = sc.nextLong();

        System.out.print("Enter generator (alfa): ");
        long g = sc.nextLong();

        // Private keys
        System.out.print("Enter private key of User A (Xa): ");
        long a = sc.nextLong();

        System.out.print("Enter private key of User B (Xb): ");
        long b = sc.nextLong();

        // Public keys
        long A = modExp(g, a, p); // A = g^Xa mod p
        long B = modExp(g, b, p); // B = g^Xb mod p

        System.out.println("\nPublic key of User A = " + A);
        System.out.println("Public key of User B = " + B);   

        // Shared secret keys
        long keyA = modExp(B, a, p); // B^Xa mod p
        long keyB = modExp(A, b, p); // A^Xb mod p

        System.out.println("\nShared key computed by User A = " + keyA);
        System.out.println("Shared key computed by User B = " + keyB);

        // Verification
        if (keyA == keyB)
            System.out.println("\nKey exchange successful! Shared Secret Key = " + keyA);
        else
            System.out.println("\nKey exchange failed!");

        sc.close();
    }
}