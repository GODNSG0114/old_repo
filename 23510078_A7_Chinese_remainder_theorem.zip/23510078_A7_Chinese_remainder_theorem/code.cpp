#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;

// Extended Euclidean Algorithm
// Returns gcd, and finds x, y such that a*x + b*y = gcd(a, b)
long long extendedGCD(long long a, long long b, long long &x, long long &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    long long x1, y1;
    long long g = extendedGCD(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    return g;
}

// Modular Inverse of a mod m
long long modInverse(long long a, long long m)
{
    long long x, y;
    long long g = extendedGCD(a % m, m, x, y);
    if (g != 1)
        throw invalid_argument("Modular inverse does not exist (not coprime)");
    return (x % m + m) % m;
}

// Check if all moduli are pairwise coprime
bool arePairwiseCoprime(const vector<long long> &moduli)
{
    int n = moduli.size();
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            long long a = moduli[i], b = moduli[j];
            while (b)
            {
                long long t = b;
                b = a % b;
                a = t;
            }
            if (a != 1)
                return false;
        }
    }
    return true;
}

// Chinese Remainder Theorem Solver
long long CRT(const vector<long long> &remainders, const vector<long long> &moduli)
{
    int n = moduli.size();

    if (!arePairwiseCoprime(moduli))
        throw invalid_argument("Moduli are NOT pairwise coprime! CRT cannot be applied.");

    // Compute M = product of all moduli
    long long M = 1;
    for (int i = 0; i < n; i++)
        M *= moduli[i];

    cout << "\nM (product of all moduli) = " << M << endl;
    cout << string(52, '-') << endl;

    long long x = 0;
    for (int i = 0; i < n; i++)
    {
        long long Mi = M / moduli[i];
        long long yi = modInverse(Mi, moduli[i]);
        long long term = remainders[i] * Mi * yi;
        x += term;

        cout << "  i=" << i + 1
             << ": a=" << remainders[i]
             << ", m=" << moduli[i]
             << ", M" << i + 1 << "=" << Mi
             << ", y" << i + 1 << "=" << yi
             << ", term=" << term << endl;
    }

    return x % M;
}

// Verify the solution
void verify(long long x, const vector<long long> &remainders, const vector<long long> &moduli)
{
    cout << "\nVerification:" << endl;
    bool allPass = true;
    for (int i = 0; i < (int)moduli.size(); i++)
    {
        bool pass = (x % moduli[i] == remainders[i]);
        cout << "  " << x << " mod " << moduli[i]
             << " = " << x % moduli[i]
             << "  (Expected: " << remainders[i] << ")"
             << "  --> " << (pass ? "PASS ✓" : "FAIL ✗") << endl;
        if (!pass)
            allPass = false;
    }
    cout << "\n  Overall: " << (allPass ? "ALL TESTS PASSED ✓" : "SOME TESTS FAILED ✗") << endl;
}

void runTestCase(int tcNum, vector<long long> remainders, vector<long long> moduli)
{
    cout << "\n"
         << string(52, '=') << endl;
    cout << "  TEST CASE " << tcNum << endl;
    cout << string(52, '=') << endl;

    cout << "\nSystem of Congruences:" << endl;
    for (int i = 0; i < (int)moduli.size(); i++)
        cout << "  x ≡ " << remainders[i] << " (mod " << moduli[i] << ")" << endl;

    try
    {
        long long result = CRT(remainders, moduli);
        long long M = 1;
        for (auto m : moduli)
            M *= m;

        cout << "\nSolution: x = " << result << " (mod " << M << ")" << endl;
        verify(result, remainders, moduli);
    }
    catch (const exception &e)
    {
        cout << "Error: " << e.what() << endl;
    }
}

int main()
{
    cout << string(52, '=') << endl;
    cout << string(52, '=') << endl;

    cout<<" Test Case 1: x≡2(mod3), x≡3(mod5), x≡2(mod7)";
    runTestCase(1, {2, 3, 2}, {3, 5, 7});

   cout<< "Test Case 2: x≡1(mod5), x≡2(mod7), x≡3(mod11)";
    runTestCase(2, {1, 2, 3}, {5, 7, 11});

    cout<< "Test Case 3: x≡2(mod3), x≡4(mod7), x≡6(mod11)";
    runTestCase(3, {2, 4, 6}, {3, 7, 11});

    cout<< "Test Case 4: x≡0(mod4), x≡3(mod5), x≡1(mod7)";
    runTestCase(4, {0, 3, 1}, {4, 5, 7});

    cout<< "Test Case 5: four moduli";
    runTestCase(5, {2, 3, 2, 4}, {3, 5, 7, 11});

    return 0;
}