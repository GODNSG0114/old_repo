# SSL/TLS Demonstration using Wireshark

### Overview
Secure Sockets Layer (SSL) and its modern successor Transport Layer Security (TLS) are cryptographic protocols that provide **Confidentiality**, **Integrity**, and **Authentication** for data transmitted over a network. This experiment demonstrates the SSL/TLS handshake process by capturing and analyzing live network traffic using Wireshark and by running a Python simulation that walks through each phase of the protocol.

### Key Concepts Covered
1. **TLS Handshake Protocol** – The multi-step negotiation that establishes a secure session between client and server.
2. **Digital Certificates (X.509)** – Server identity verification through CA-signed certificates.
3. **Cipher Suite Negotiation** – Agreement on encryption, key-exchange, and MAC algorithms.
4. **Session Key Derivation** – Generating symmetric session keys from asymmetric key-exchange.
5. **Perfect Forward Secrecy (PFS)** – Using ephemeral DH keys so past sessions cannot be decrypted.

### TLS Handshake Messages Identified
| # | Message | Direction | Description |
|---|---------|-----------|-------------|
| 1 | **Client Hello** | C → S | TLS versions, cipher suites, client_random, extensions (SNI) |
| 2 | **Server Hello** | S → C | Chosen version, chosen cipher, server_random |
| 3 | **Certificate** | S → C | Server's X.509 certificate (public key + CA signature) |
| 4 | **Server Key Exchange** | S → C | DH/ECDH parameters (if ephemeral key exchange) |
| 5 | **Server Hello Done** | S → C | End of server handshake messages |
| 6 | **Client Key Exchange** | C → S | Pre-master secret (RSA) or client DH public value |
| 7 | **Change Cipher Spec** | Both | Switch to encrypted communication |
| 8 | **Finished** | Both | HMAC of full handshake transcript (first encrypted message) |
| 9 | **Application Data** | Both | Encrypted HTTP (HTTPS) payload |

### Wireshark Filters Used
```
tls                          → All TLS records
tls.handshake.type == 1      → Client Hello
tls.handshake.type == 2      → Server Hello
tls.handshake.type == 11     → Certificate
tcp.port == 443              → All HTTPS traffic
```

### How to Run the Python Simulation
```bash
# Install dependency (optional – for coloured output)
pip install colorama

# Run the simulation
python SSL_TLS_Simulation.py
```

### Properties Ensured by SSL/TLS
1. **Confidentiality:** Application data is encrypted with a symmetric session key (e.g., AES-256-GCM); eavesdroppers cannot read it.
2. **Integrity:** HMAC or AEAD tags detect any tampering in transit.
3. **Authentication:** The server's X.509 certificate, signed by a trusted CA, proves its identity.
4. **Non-repudiation:** Digital signatures on certificates bind identity to public keys, preventing denial of participation.
