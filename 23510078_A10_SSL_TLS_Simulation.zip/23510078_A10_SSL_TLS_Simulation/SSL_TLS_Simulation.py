"""
SSL/TLS Handshake Simulation and Wireshark Packet Analysis Demo
================================================================
Walchand College of Engineering, Sangli
Course: Cryptography and Network Security Lab (7CS372)
Experiment No: 10
Title: Demonstration of SSL using Wireshark
Student: 23510090

Description:
    This script simulates the SSL/TLS handshake process and demonstrates
    secure communication over HTTPS. It performs a real HTTPS request
    so its traffic can be captured and analyzed in Wireshark.
    It also prints a step-by-step breakdown of the TLS protocol messages.
"""

import ssl
import socket
import textwrap
import hashlib
import os
import datetime

# ──────────────────────────────────────────────────────────────────────────────
# ANSI Colour Codes (Windows-safe fallback)
# ──────────────────────────────────────────────────────────────────────────────
try:
    import colorama
    colorama.init()
    CYAN   = "\033[96m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    BOLD   = "\033[1m"
    RESET  = "\033[0m"
except ImportError:
    CYAN = GREEN = YELLOW = RED = BOLD = RESET = ""


def section(title: str) -> None:
    width = 68
    print(f"\n{CYAN}{BOLD}{'─' * width}{RESET}")
    print(f"{CYAN}{BOLD}  {title}{RESET}")
    print(f"{CYAN}{BOLD}{'─' * width}{RESET}")


def step(number: int, description: str) -> None:
    print(f"\n{YELLOW}[Step {number}]{RESET} {description}")


def info(label: str, value: str) -> None:
    print(f"  {GREEN}{label:<28}{RESET} {value}")


# ──────────────────────────────────────────────────────────────────────────────
# 1. TLS Handshake Theory Walkthrough
# ──────────────────────────────────────────────────────────────────────────────
def print_tls_theory() -> None:
    section("SSL/TLS HANDSHAKE – CONCEPTUAL OVERVIEW")

    messages = [
        ("Client Hello",
         "Client → Server: Supported TLS versions, cipher suites,\n"
         "                            random nonce (client_random), session ID."),
        ("Server Hello",
         "Server → Client: Chosen TLS version, chosen cipher suite,\n"
         "                            server_random, session ID."),
        ("Certificate",
         "Server → Client: Server's X.509 digital certificate containing\n"
         "                            its public key, signed by a trusted CA."),
        ("Server Key Exchange",
         "Server → Client: (if needed) Diffie-Hellman parameters for\n"
         "                            ephemeral key agreement (DHE/ECDHE)."),
        ("Server Hello Done",
         "Server → Client: Signals end of server's handshake messages."),
        ("Client Key Exchange",
         "Client → Server: Pre-master secret encrypted with server's\n"
         "                            public key (RSA) OR client DH public value."),
        ("Change Cipher Spec",
         "Both sides signal that subsequent messages will be encrypted\n"
         "                            using the negotiated session keys."),
        ("Finished",
         "Both sides send a MAC of the entire handshake, proving\n"
         "                            successful key negotiation. First encrypted message."),
        ("Application Data",
         "Encrypted HTTP (HTTPS) data flows bidirectionally using the\n"
         "                            symmetric session key (e.g., AES-256-GCM)."),
    ]

    for i, (name, desc) in enumerate(messages, 1):
        print(f"\n  {BOLD}{i:>2}. {YELLOW}{name}{RESET}")
        for line in desc.split("\n"):
            print(f"      {line}")


# ──────────────────────────────────────────────────────────────────────────────
# 2. Live HTTPS Connection – Capture in Wireshark
# ──────────────────────────────────────────────────────────────────────────────
def perform_https_connection(hostname: str = "www.example.com", port: int = 443) -> None:
    section(f"LIVE TLS CONNECTION TO {hostname}:{port}")
    print(f"  {RED}>>> CAPTURE THIS TRAFFIC IN WIRESHARK using filter: tls{RESET}\n")

    step(1, f"Creating TCP socket to {hostname}:{port}")
    raw_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    raw_sock.settimeout(10)

    step(2, "Wrapping socket in TLS context (SSL handshake will begin)")
    ctx = ssl.create_default_context()

    try:
        conn = ctx.wrap_socket(raw_sock, server_hostname=hostname)
        conn.connect((hostname, port))

        step(3, "TLS Handshake Complete!")
        cipher_name, tls_version, bits = conn.cipher()
        cert = conn.getpeercert()

        info("TLS Version :", tls_version)
        info("Cipher Suite :", cipher_name)
        info("Key Length (bits) :", str(bits))
        info("Server Subject :", str(cert.get("subject", [{}])[0]))
        info("Issued By :", str(cert.get("issuer", [{}])[0]))

        # Validity
        not_before = cert.get("notBefore", "N/A")
        not_after  = cert.get("notAfter",  "N/A")
        info("Certificate Valid From :", not_before)
        info("Certificate Valid Until :", not_after)

        # SAN
        san_list = cert.get("subjectAltName", [])
        san_str  = ", ".join(f"{k}:{v}" for k, v in san_list[:5])
        info("SANs (first 5) :", san_str)

        step(4, "Sending HTTP GET request over encrypted channel")
        http_request = (
            f"GET / HTTP/1.1\r\n"
            f"Host: {hostname}\r\n"
            f"Connection: close\r\n\r\n"
        )
        conn.sendall(http_request.encode())

        step(5, "Receiving encrypted HTTP response (decrypted by TLS layer)")
        response = b""
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            response += chunk

        status_line = response.split(b"\r\n")[0].decode(errors="replace")
        info("HTTP Response Status :", status_line)
        info("Response Size :", f"{len(response)} bytes")

        conn.close()
        print(f"\n  {GREEN}✔  Connection closed gracefully (TLS alert: close_notify sent){RESET}")

    except Exception as exc:
        print(f"\n  {RED}Connection error: {exc}{RESET}")
        print(f"  (Check your internet connection or try another hostname)")


# ──────────────────────────────────────────────────────────────────────────────
# 3. Simulated Handshake (Offline Demo with Random Values)
# ──────────────────────────────────────────────────────────────────────────────
def simulate_tls_handshake() -> None:
    section("SIMULATED TLS 1.3 HANDSHAKE (Offline Representation)")

    client_random = os.urandom(32)
    server_random = os.urandom(32)
    pre_master    = os.urandom(48)
    master_secret = hashlib.sha256(client_random + server_random + pre_master).digest()
    session_key   = hashlib.sha256(master_secret + b"key_expansion").digest()[:16]

    timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    print(f"\n  Timestamp : {timestamp}")

    step(1, "CLIENT HELLO")
    info("client_random (hex) :", client_random.hex()[:40] + "…")
    info("Supported Versions :", "TLS 1.2, TLS 1.3")
    info("Cipher Suites :",
         "TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256")
    info("Compression Methods :", "null")
    info("Extensions :", "server_name, supported_groups, key_share")

    step(2, "SERVER HELLO")
    info("server_random (hex) :", server_random.hex()[:40] + "…")
    info("Selected Version :", "TLS 1.3")
    info("Selected Cipher Suite :", "TLS_AES_256_GCM_SHA384")
    info("Session ID :", os.urandom(16).hex())

    step(3, "CERTIFICATE (Server)")
    info("Subject :", "CN=www.example.com, O=Example Corp, C=US")
    info("Issuer :", "CN=DigiCert TLS RSA SHA256 2020 CA1")
    info("Signature Algorithm :", "RSA with SHA-256")
    info("Public Key :", "RSA 2048-bit")
    info("Valid :", "2024-01-01 → 2026-01-01")

    step(4, "KEY EXCHANGE & SESSION KEY DERIVATION")
    info("Pre-Master Secret (hex) :", pre_master.hex()[:40] + "…")
    info("Master Secret (hex) :", master_secret.hex()[:40] + "…")
    info("Session Key (AES-128) :", session_key.hex())

    step(5, "CHANGE CIPHER SPEC  +  FINISHED (Both Sides)")
    print(f"      {GREEN}Both parties switch to encrypted communication.{RESET}")
    print(f"      A MAC of the full handshake transcript is exchanged.")
    print(f"      {GREEN}✔  Handshake verified – secure channel established!{RESET}")

    step(6, "APPLICATION DATA (Encrypted)")
    sample_plaintext = b"GET / HTTP/1.1\r\nHost: www.example.com\r\n\r\n"
    # XOR with session key bytes as a simplistic demo cipher
    key_stream = (session_key * ((len(sample_plaintext) // 16) + 1))[:len(sample_plaintext)]
    ciphertext = bytes(a ^ b for a, b in zip(sample_plaintext, key_stream))
    info("Plaintext  :", sample_plaintext.decode().replace("\r\n", " | "))
    info("Ciphertext (hex) :", ciphertext.hex()[:50] + "…")
    print(f"\n  {RED}Note: Real encryption uses AES-GCM with authentication tags.{RESET}")
    print(f"  {RED}      The above is a simplified XOR demo for illustration only.{RESET}")


# ──────────────────────────────────────────────────────────────────────────────
# 4. Wireshark Capture Guide
# ──────────────────────────────────────────────────────────────────────────────
def print_wireshark_guide() -> None:
    section("WIRESHARK CAPTURE & ANALYSIS GUIDE")

    guide = """
  HOW TO CAPTURE SSL/TLS TRAFFIC IN WIRESHARK
  ─────────────────────────────────────────────
  1. Open Wireshark as Administrator.
  2. Select the active network interface (Wi-Fi or Ethernet).
  3. Apply the capture filter:   tcp port 443
  4. Run this Python script to generate HTTPS traffic.
  5. Stop the capture after the script finishes.

  DISPLAY FILTERS (use in the Wireshark filter bar)
  ─────────────────────────────────────────────────
  • tls                          → All TLS records
  • tls.handshake.type == 1      → Client Hello
  • tls.handshake.type == 2      → Server Hello
  • tls.handshake.type == 11     → Certificate
  • tls.handshake.type == 16     → Client Key Exchange
  • tls.handshake.type == 20     → Finished
  • tcp.port == 443              → All HTTPS traffic
  • ip.addr == <server_ip>       → Traffic to/from specific server

  KEY FIELDS TO INSPECT IN WIRESHARK PACKETS
  ─────────────────────────────────────────────
  • Packet #1 (Client Hello):
      Transport Layer Security → Handshake Protocol: Client Hello
      → Version, Random, Cipher Suites, Extensions (SNI)

  • Packet #2 (Server Hello):
      → Chosen Cipher Suite, Server Random, Session ID

  • Packet #3 (Certificate):
      → Certificate Length, Issuer, Subject, Validity, Public Key

  • Packet #N (Application Data):
      → Content Type: Application Data (23)
      → Data is opaque/encrypted – cannot be read in plaintext

  OBSERVATIONS TO NOTE
  ─────────────────────
  ✔  Client Hello and Server Hello are in PLAINTEXT (readable in Wireshark).
  ✔  Certificate details are visible (public information).
  ✔  Application Data is fully encrypted – only length is visible.
  ✔  TLS 1.3 encrypts even more of the handshake than TLS 1.2.
"""
    print(guide)


# ──────────────────────────────────────────────────────────────────────────────
# Main Entry Point
# ──────────────────────────────────────────────────────────────────────────────
def main() -> None:
    print(f"\n{BOLD}{CYAN}{'═' * 68}{RESET}")
    print(f"{BOLD}{CYAN}   SSL/TLS Demonstration – CNS Lab Experiment 10{RESET}")
    print(f"{BOLD}{CYAN}   Walchand College of Engineering, Sangli{RESET}")
    print(f"{BOLD}{CYAN}{'═' * 68}{RESET}")

    # Theoretical walkthrough
    print_tls_theory()

    # Offline simulation
    simulate_tls_handshake()

    # Wireshark guide
    print_wireshark_guide()

    # Live HTTPS connection
    print(f"\n{YELLOW}Do you want to perform a LIVE HTTPS connection to www.example.com?")
    print(f"(Make sure Wireshark is running to capture the TLS traffic){RESET}")
    choice = input("  Enter [Y/N]: ").strip().upper()

    if choice == "Y":
        perform_https_connection("www.example.com", 443)
    else:
        print(f"\n  {GREEN}Skipping live connection. All simulation steps completed.{RESET}")

    section("CONCLUSION")
    print("""
  • SSL/TLS provides Confidentiality, Integrity, and Authentication.
  • The handshake negotiates algorithms and establishes session keys.
  • Digital certificates bind a server's identity to its public key.
  • Wireshark reveals handshake metadata but CANNOT decrypt application data.
  • TLS 1.3 is the current standard, offering forward secrecy by default.
  • Perfect Forward Secrecy (PFS) ensures past sessions stay safe even if
    the server's private key is later compromised.
""")
    print(f"{BOLD}{CYAN}{'═' * 68}{RESET}\n")


if __name__ == "__main__":
    main()
